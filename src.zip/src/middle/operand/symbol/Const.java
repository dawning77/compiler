package middle.operand.symbol;

public interface Const {
}
