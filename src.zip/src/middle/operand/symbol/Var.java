package middle.operand.symbol;

public class Var extends Symbol{
	public Var(String name, Type type){
		super(name, type, 1);
	}
}
