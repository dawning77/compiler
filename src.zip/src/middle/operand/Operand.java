package middle.operand;

public interface Operand {
	String toString();
}
