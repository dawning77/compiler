package frontend.symbol;

public class Symbol {
    public String name;
    public String type;
    public int line;

    public Symbol(String name, String type, int line) {
        this.name = name;
        this.type = type;
        this.line = line;
    }
}
