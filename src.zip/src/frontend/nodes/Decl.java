package frontend.nodes;

public interface Decl extends BlockItem{

}
