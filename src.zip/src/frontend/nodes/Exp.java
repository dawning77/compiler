package frontend.nodes;

public interface Exp {
}
