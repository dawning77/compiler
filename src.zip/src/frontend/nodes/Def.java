package frontend.nodes;

public interface Def {
}
