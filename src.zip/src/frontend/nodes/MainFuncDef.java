package frontend.nodes;

public class MainFuncDef {
    public Block block;

    public MainFuncDef(Block block) {
        this.block = block;
    }
}
