package frontend.nodes;

public interface ConstExp {
}
