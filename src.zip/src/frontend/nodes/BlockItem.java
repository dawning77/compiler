package frontend.nodes;

public interface BlockItem {
}
