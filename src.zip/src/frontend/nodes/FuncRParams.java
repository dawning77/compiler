package frontend.nodes;

import java.util.ArrayList;

public class FuncRParams {
    public ArrayList<Exp> exps;

    public FuncRParams(ArrayList<Exp> exps) {
        this.exps = exps;
    }
}
