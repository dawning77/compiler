package frontend.nodes;

import java.util.ArrayList;

public class Block {
    public ArrayList<BlockItem> blockItems;

    public Block(ArrayList<BlockItem> blockItems) {
        this.blockItems = blockItems;
    }
}
