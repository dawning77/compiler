package frontend.nodes;

public interface Cond {
}
