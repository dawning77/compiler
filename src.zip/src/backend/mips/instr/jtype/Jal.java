package backend.mips.instr.jtype;

public class Jal extends JType{
	public Jal(String label){ super(label); }
}
