package backend.mips.instr.jtype;

public class J extends JType{
	public J(String label){
		super(label);
	}
}
