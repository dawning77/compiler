package backend.mips.instr;

public interface Instr{
	@Override
	String toString();
}
