package backend.mips.instr.rtype;

import backend.mips.reg.*;

public class Or extends RType{
	public Or(Reg rs, Reg rt, Reg rd){
		super(rs, rt, rd);
	}
}
