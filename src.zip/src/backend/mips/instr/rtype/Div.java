package backend.mips.instr.rtype;

import backend.mips.reg.*;

public class Div extends RType{
	public Div(Reg rs, Reg rt, Reg rd){
		super(rs, rt, rd);
	}
}
